BRIZ KING CONSTRUCTION RECORD KEEPER — ANDROID PROJECT (VERSION 5)

This project wraps the existing Version 5 HTML app in a simple Android WebView.
It is Android source code, not a compiled APK yet.

BUILD THE APK
1. On a computer, install Android Studio from the official Android developer website.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted BrizKing_Construction_Record_Keeper_Android folder.
4. Allow Android Studio to download/install the required Android Gradle Plugin and Android SDK components.
5. Wait for Gradle sync to finish.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. When finished, use the notification's Locate link. The APK is normally in:
   app/build/outputs/apk/debug/app-debug.apk
8. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

IMPORTANT DATA NOTE
- The app stores its records in browser local storage. In a WebView, these records are stored inside this app's private data.
- Uninstalling the app or clearing its data can erase records. Use the app's Backup / Export function regularly.
- Before relying on it for real project accounts, test adding income, materials, labour, and expenses, confirm each project's balance, and test backup/restore.
- This project has not been compiled or tested in Android Studio in this environment. Android Studio may prompt for SDK/Gradle downloads.

PHONE-ONLY CLOUD BUILD OPTION (GitHub Actions)
This ZIP includes a workflow at .github/workflows/build-apk.yml to build the APK in GitHub's cloud.
You still need to put the extracted project files into a GitHub repository. From a phone this can be fiddly because the GitHub website may not upload a complete folder tree in one step. Once the files are in the repository:
1. Open the repository in your browser.
2. Tap Actions and select "Build Briz King APK".
3. Tap Run workflow.
4. When the run finishes successfully, open it and download the artifact named "BrizKing-Construction-Record-Keeper-APK".
The artifact is a ZIP containing app-debug.apk. Extract it on your phone, then tap the APK to install it.
